#include <signal.h>
#include <pthread.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>
#include "sqlite3.h"

#define SQLITE_UNIX_THREADS 1

extern void sqlite3UnixEnterMutex();
extern void sqlite3UnixLeaveMutex();
void deadlock0()
{
  sqlite3UnixEnterMutex();
  sqlite3UnixEnterMutex();
  
  printf("deadlock0 \n");
  
  sqlite3UnixLeaveMutex();
  sqlite3UnixLeaveMutex();
}


void deadlock1()
{
  sqlite3UnixEnterMutex();

  printf("deadlock1 \n");
  
  sqlite3UnixLeaveMutex();
}

void* work0(void* arg)
{
  deadlock0();
  return 0;
}

void* work1(void* arg)
{
  deadlock1();
  return 0;
}

int main(int argc, char* argv[])
{
  pthread_t t0, t1;
  int rc;

  // printf("deadlock0 func \n"); 
  sqlite3 *db;
  char *zErrMsg = 0;
  char dbname[10];

  rc = sqlite3_open(dbname, &db);

  if( rc ){
    fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
    sqlite3_close(db);
    exit(1);
  }

  sqlite3_close(db);
  printf("ENTERING\n");
  rc = pthread_create (&t0, 0, work0, 0);
  rc = pthread_create (&t1, 0, work1, 0);
    
  pthread_join(t0, 0);
  pthread_join(t1, 0);
    
  return 0;
}
